# Bio da Luana Souza
## Sobre mim
Meu nome é Luana, 36 anos , mãe da Evellyn de 18 anos, 5 cachorros, e dois gatos. Moro no Rio , sou motociclista, resolvi aprender a surfar tem dois anos, e resolvi aprender programação que é um sonho de infância. Boraaaaaaaaaaaaaaaaaa!!!
